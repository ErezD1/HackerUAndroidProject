package com.example.finalprojectapi.ui.difficulty

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.finalprojectapi.R
import com.example.finalprojectapi.databinding.FragmentDifficultyBinding  // <-- Import for Data Binding
import com.example.finalprojectapi.ui.viewmodels.SharedViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class DifficultyFragment : Fragment(R.layout.fragment_difficulty) {

    private var _binding: FragmentDifficultyBinding? = null
    private val binding get() = _binding!!
    private val sharedViewModel: SharedViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDifficultyBinding.inflate(inflater, container, false)
        binding.sharedViewModel = sharedViewModel
        binding.lifecycleOwner = viewLifecycleOwner
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sharedViewModel.difficulties.observe(viewLifecycleOwner) { _ ->
            // This block will run whenever the difficulties LiveData changes
            binding.btnEasy.setOnClickListener { navigateToQuestionFragment(SharedViewModel.Difficulty.EASY) }
            binding.btnMedium.setOnClickListener { navigateToQuestionFragment(SharedViewModel.Difficulty.MEDIUM) }
            binding.btnHard.setOnClickListener { navigateToQuestionFragment(SharedViewModel.Difficulty.HARD) }

        }
    }

    private fun navigateToQuestionFragment(difficulty: SharedViewModel.Difficulty) {
        sharedViewModel.setSelectedDifficulty(difficulty.value)  // Pass the string representation
        findNavController().navigate(R.id.actionDifficultyFragmentToQuestionFragment)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
