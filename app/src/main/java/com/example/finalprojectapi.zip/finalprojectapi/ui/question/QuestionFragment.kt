package com.example.finalprojectapi.ui.question

import android.os.Build
import android.os.Bundle
import android.text.Html
import android.text.Spanned
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.*
import androidx.navigation.fragment.findNavController
import com.example.finalprojectapi.R
import com.example.finalprojectapi.databinding.FragmentQuestionBinding
import com.example.finalprojectapi.model.Question
import com.example.finalprojectapi.ui.viewmodels.SharedViewModel
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class QuestionFragment : Fragment(R.layout.fragment_question) {

    private var _binding: FragmentQuestionBinding? = null
    private val binding get() = _binding!!
    private val sharedViewModel: SharedViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentQuestionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val categoryId = sharedViewModel.selectedCategory.value?.id
        val difficulty = sharedViewModel.selectedDifficulty.value

        if (categoryId != null && difficulty != null) {
            sharedViewModel.fetchQuestions(categoryId, difficulty)
        }

        // Observe the questionsList
        sharedViewModel.questionsList.observe(viewLifecycleOwner) {
            updateQuestionUI(it)
        }

        // Observe the questionIndex
        sharedViewModel.questionIndex.observe(viewLifecycleOwner) {
            updateQuestionUI(sharedViewModel.questionsList.value)
        }

        // Handle the answer submission
        binding.btnSubmit.setOnClickListener {
            val selectedAnswer = when (binding.rgChoices.checkedRadioButtonId) {
                binding.rbChoice1.id -> binding.rbChoice1.text.toString()
                binding.rbChoice2.id -> binding.rbChoice2.text.toString()
                binding.rbChoice3.id -> binding.rbChoice3.text.toString()
                binding.rbChoice4.id -> binding.rbChoice4.text.toString()
                else -> ""
            }

            val (isCorrect, correctAnswer) = sharedViewModel.checkAnswer(selectedAnswer)

            if (isCorrect) {
                showToast("Correct!")
            } else {
                showToast("Incorrect! The correct answer is $correctAnswer.")
            }

            // Check if we've reached the last question
            if ((sharedViewModel.questionIndex.value ?: 0) >= (sharedViewModel.questionsList.value?.size ?: 0) - 1) {
                sharedViewModel.saveScore()
                val actionId = R.id.action_questionFragment_to_resultFragment
                findNavController().navigate(actionId)
            }
        }
    }

    private fun updateQuestionUI(questions: List<Question>?) {
        val question = questions?.getOrNull(sharedViewModel.questionIndex.value ?: 0)
        question?.let {
            Log.d("QuestionFragment", "Current question: $it")
            val decodedQuestion = fromHtml(it.question).toString()
            binding.tvQuestion.text = decodedQuestion

            val options = it.incorrectAnswers.toMutableList()
            options.add(it.correctAnswer)
            options.shuffle()

            // Decode the options
            binding.rbChoice1.text = fromHtml(options[0]).toString()
            binding.rbChoice2.text = fromHtml(options[1]).toString()
            binding.rbChoice3.text = fromHtml(options[2]).toString()
            binding.rbChoice4.text = fromHtml(options[3]).toString()
        } ?: Log.e("QuestionFragment", "Current question is null")
    }

    // Inside QuestionFragment
    private var currentToast: Toast? = null
    private fun showToast(message: String) {
        currentToast?.cancel()

        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.custom_toast_layout, requireActivity().findViewById(R.id.custom_toast_message))

        val text: TextView = layout.findViewById(R.id.custom_toast_message)
        text.text = fromHtml(message).toString()  // Use fromHtml here

        val toast = Toast(requireContext())
        //toast.setGravity(Gravity.CENTER, 0, 0)
        toast.duration = Toast.LENGTH_SHORT
        toast.view = layout
        toast.show()

        currentToast = toast
    }
    //Handle the unique format from the API to show the special letters.
    @Suppress("DEPRECATION")
    private fun fromHtml(html: String): Spanned {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
        } else {
            Html.fromHtml(html)
        }
    }


        override fun onDestroyView() {
            super.onDestroyView()
            _binding = null
        }
    }


