package com.example.finalprojectapi.ui.start

import androidx.lifecycle.ViewModel

class StartPageViewModel : ViewModel() {
    // Add any necessary logic for StartPageFragment here
}
